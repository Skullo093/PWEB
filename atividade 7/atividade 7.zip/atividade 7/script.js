// Fase b: o computador faz uma escolha usando Math.random()
function escolhaDoComputador() {
  var numero = Math.random(); // de 0 (inclusivo) até 1 (exclusivo)

  if (numero < 0.33) {
    return "pedra";
  } else if (numero < 0.66) {
    return "papel";
  } else {
    return "tesoura";
  }
}

// Fase c: determina o vencedor a partir das duas escolhas
function determinarVencedor(usuario, computador) {
  if (usuario === computador) {
    return "Empate!";
  }
  if (usuario === "pedra" && computador === "tesoura") {
    return "Pedra quebra tesoura. Você venceu! 🎉";
  }
  if (usuario === "tesoura" && computador === "papel") {
    return "Tesoura corta papel. Você venceu! 🎉";
  }
  if (usuario === "papel" && computador === "pedra") {
    return "Papel cobre a pedra. Você venceu! 🎉";
  }
  if (computador === "pedra" && usuario === "tesoura") {
    return "Pedra quebra tesoura. O computador venceu! 💻";
  }
  if (computador === "tesoura" && usuario === "papel") {
    return "Tesoura corta papel. O computador venceu! 💻";
  }
  return "Papel cobre a pedra. O computador venceu! 💻";
}

// Fase a: o usuário faz uma escolha (clique no botão)
function jogar(escolhaUsuario) {
  var escolhaComputador = escolhaDoComputador();
  var resultado = determinarVencedor(escolhaUsuario, escolhaComputador);

  document.getElementById("escolhaUsuario").textContent = "Você escolheu: " + escolhaUsuario;
  document.getElementById("escolhaComputador").textContent = "Computador escolheu: " + escolhaComputador;
  document.getElementById("vencedor").textContent = resultado;
}
