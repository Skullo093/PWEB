/**
 * 1) Recebe três números e retorna o maior deles.
 */
function retornarMaior(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

/**
 * 2) Recebe três números e retorna-os em ordem crescente.
 */
function ordenarCrescente(num1, num2, num3) {
    let numeros = [num1, num2, num3];
    numeros.sort((a, b) => a - b);
    return numeros;
}

/**
 * 3) Recebe uma string e retorna se ela é palíndromo ou não.
 * (Converte para maiúsculas/minúsculas e retira espaços em branco)
 */
function verificarPalindromo(texto) {
    if (!texto) return "Texto inválido";
    
    // Converte para minúsculas e remove todos os espaços em branco
    let limpo = texto.toLowerCase().replace(/\s+/g, '');
    let invertido = limpo.split('').reverse().join('');
    
    if (limpo === invertido) {
        return "É um palíndromo";
    } else {
        return "Não é um palíndromo";
    }
}

/**
 * 4) Recebe duas palavras como parâmetros:
 * - Retorna "erro" se uma delas/ou duas são vazias ou undefined.
 * - Retorna "é um subconjunto" se a segunda palavra é um subconjunto da primeira.
 * - Retorna "não é um subconjunto" caso contrário.
 * (Utiliza o método .includes() do tipo String)
 */
function verificarSubconjunto(palavra1, palavra2) {
    if (!palavra1 || !palavra2 || palavra1.trim() === "" || palavra2.trim() === "") {
        return "erro";
    }
    
    let p1 = palavra1.toLowerCase();
    let p2 = palavra2.toLowerCase();
    
    if (p1.includes(p2)) {
        return "é um subconjunto";
    } else {
        return "não é um subconjunto";
    }
}

/**
 * 5) Recebe uma data e devolve o dia da semana por extenso.
 */
function obterDiaSemana(dataString) {
    if (!dataString) return "Data inválida";
    
    // Ajusta o timezone ao instanciar o Date para evitar descolamento de dia
    let partes = dataString.split('-');
    let data = new Date(partes[0], partes[1] - 1, partes[2]);
    
    let diasSemana = [
        "Domingo", 
        "Segunda-feira", 
        "Terça-feira", 
        "Quarta-feira", 
        "Quinta-feira", 
        "Sexta-feira", 
        "Sábado"
    ];
    
    return diasSemana[data.getDay()];
}

function testarExercicio1() {
    let n1 = Number(document.getElementById('ex1_n1').value);
    let n2 = Number(document.getElementById('ex1_n2').value);
    let n3 = Number(document.getElementById('ex1_n3').value);
    
    let resultado = retornarMaior(n1, n2, n3);
    document.getElementById('res1').innerText = "Resultado: O maior número é " + resultado;
}

function testarExercicio2() {
    let n1 = Number(document.getElementById('ex2_n1').value);
    let n2 = Number(document.getElementById('ex2_n2').value);
    let n3 = Number(document.getElementById('ex2_n3').value);
    
    let resultado = ordenarCrescente(n1, n2, n3);
    document.getElementById('res2').innerText = "Resultado: " + resultado.join(', ');
}

function testarExercicio3() {
    let texto = document.getElementById('ex3_texto').value;
    let resultado = verificarPalindromo(texto);
    document.getElementById('res3').innerText = "Resultado: " + resultado;
}

function testarExercicio4() {
    let p1 = document.getElementById('ex4_p1').value;
    let p2 = document.getElementById('ex4_p2').value;
    
    let resultado = verificarSubconjunto(p1, p2);
    document.getElementById('res4').innerText = "Resultado: " + resultado;
}

function testarExercicio5() {
    let dataVal = document.getElementById('ex5_data').value;
    let resultado = obterDiaSemana(dataVal);
    document.getElementById('res5').innerText = "Resultado: " + resultado;
}